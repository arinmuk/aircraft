A simple one-page Dashboard written on JavaScript. Uses Data Visualization tools such as WebDataRocks and Fusioncharts
